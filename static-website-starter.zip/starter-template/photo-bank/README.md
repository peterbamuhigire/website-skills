# Photo Bank

Drop client photos here with descriptive names.

## Naming Convention
- `hero-*.jpg` — hero/banner images (wide, min 1600px)
- `team-*.jpg` — team member headshots (square preferred)
- `service-*.jpg` — service/product images
- `gallery-*.jpg` — portfolio/gallery images
- `about-*.jpg` — about page images
- `client-*.jpg` — client logos/photos

Claude Code will catalog dimensions and organize these into the site.
