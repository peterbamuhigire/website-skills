## John Doe
**role:** CEO & Founder
**photo:** team-john.jpg
**bio:** [Brief biography — 2-3 sentences about background and role.]
**linkedin:** https://linkedin.com/in/johndoe
**email:** john@company.com

## Jane Smith
**role:** Head of Operations
**photo:** team-jane.jpg
**bio:** [Brief biography — 2-3 sentences about background and role.]
**linkedin:** https://linkedin.com/in/janesmith
**email:** jane@company.com

## David Okello
**role:** Lead Engineer
**photo:** team-david.jpg
**bio:** [Brief biography — 2-3 sentences about background and role.]
**linkedin:**
**email:** david@company.com
