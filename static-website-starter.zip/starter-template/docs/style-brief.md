---
# Design Direction
mood: "professional yet warm"
industry_feel: "construction"
primary_color: ""
secondary_color: ""
accent_color: ""
dark_mode: false
preferred_style: ""
references: ""
---

## Brand Notes
[Any existing brand guidelines — logo colors, fonts they already use, things to avoid.
Leave blank and Claude will make creative choices based on the industry.]

## Content Tone
[Professional, friendly, authoritative, casual, etc.]

## Special Requests
[Any specific design requests — e.g., "we want a dark theme", "include a project gallery", "hero should show our team, not stock photos"]
