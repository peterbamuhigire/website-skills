---
pages:
  - slug: "/"
    title: "Home"
    sections: [hero, services-overview, about-snippet, testimonials, cta]
  - slug: "/about"
    title: "About Us"
    sections: [hero, story, mission-vision, team-preview, numbers]
  - slug: "/services"
    title: "Services"
    sections: [hero, service-list-detailed, process, cta]
  - slug: "/team"
    title: "Our Team"
    sections: [hero, team-grid]
  - slug: "/contact"
    title: "Contact"
    sections: [hero, contact-info, form]
nav_order: [Home, About, Services, Team, Contact]
cta_text: "Get in Touch"
cta_link: "/contact"
---

## Notes
[Add any notes about page structure, special pages needed, etc.]
[Remove or add pages as needed — this is just a starting template.]
