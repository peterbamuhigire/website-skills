---
address: "Plot 12, Kampala Road, Kampala, Uganda"
phone: "+256 700 000000"
email: "info@company.com"
hours: "Monday - Friday: 8:00 AM - 5:00 PM"
map_embed: ""
---

## Get in Touch
[Optional paragraph inviting visitors to reach out.]

## Office Location
[Description of where the office is, landmarks, parking info, etc.]
