---
service_count: 4
---

## Service 1: [Service Name]
**summary:** [One-line summary for cards]
**description:** [Full paragraph describing this service]
**icon:** shield
**features:**
- Feature A
- Feature B
- Feature C

## Service 2: [Service Name]
**summary:** [One-line summary for cards]
**description:** [Full paragraph describing this service]
**icon:** building
**features:**
- Feature A
- Feature B
- Feature C

## Service 3: [Service Name]
**summary:** [One-line summary for cards]
**description:** [Full paragraph describing this service]
**icon:** users
**features:**
- Feature A
- Feature B
- Feature C

## Service 4: [Service Name]
**summary:** [One-line summary for cards]
**description:** [Full paragraph describing this service]
**icon:** chart-line
**features:**
- Feature A
- Feature B
- Feature C
