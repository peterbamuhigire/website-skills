---
name: "ACME Corporation"
tagline: "Building Tomorrow, Today"
industry: "Construction & Engineering"
founded: "2010"
location: "Kampala, Uganda"
email: "info@acmecorp.ug"
phone: "+256 700 000000"
website: "https://acmecorp.ug"
social:
  twitter: ""
  linkedin: "https://linkedin.com/company/acmecorp"
  facebook: "https://facebook.com/acmecorp"
  instagram: ""
---

## About
[Write 2-3 paragraphs about the company — what they do, who they serve, what makes them different.]

## Mission
[One clear mission statement.]

## Vision
[One aspirational vision statement.]

## Values
- Excellence: [Description]
- Integrity: [Description]
- Innovation: [Description]
- Community: [Description]

## History
[The company's story — founding, growth milestones, key achievements.]

## Key Numbers
- Clients served: 500+
- Years in business: 15
- Team size: 50
- Projects completed: 200+
