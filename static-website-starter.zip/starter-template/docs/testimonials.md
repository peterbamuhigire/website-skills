## Testimonial 1
**name:** Sarah Nalubega
**role:** Managing Director, XYZ Ltd
**photo:** client-sarah.jpg
**quote:** "[Client testimonial quote — 1-3 sentences about their experience.]"

## Testimonial 2
**name:** Michael Ochieng
**role:** CEO, ABC Holdings
**photo:** client-michael.jpg
**quote:** "[Client testimonial quote — 1-3 sentences about their experience.]"

## Testimonial 3
**name:** Grace Namukasa
**role:** Operations Manager, DEF Corp
**photo:** client-grace.jpg
**quote:** "[Client testimonial quote — 1-3 sentences about their experience.]"
